(function() {
  let orderIDs = [];
  // Updated regex to capture the text after "Order ID"
  const regex = /Order ID\s*([\w-]+)/g;
  const bodyText = document.body.innerText;
  let match;
  
  while ((match = regex.exec(bodyText)) !== null) {
    orderIDs.push(match[1]);
  }
  
  const textToCopy = orderIDs.join('\n');
  console.log('Order IDs found:', textToCopy);

  // Fallback method to copy text to clipboard
  function fallbackCopyTextToClipboard(text) {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      const successful = document.execCommand('copy');
      const msg = successful ? 'successful' : 'unsuccessful';
      console.log('Fallback: Copying text command was ' + msg);
      alert('Copied Order IDs to clipboard!');
    } catch (err) {
      console.error('Fallback: Oops, unable to copy', err);
    }
    document.body.removeChild(textArea);
  }

  if (!navigator.clipboard) {
    console.warn('Clipboard API not available, using fallback method');
    fallbackCopyTextToClipboard(textToCopy);
  } else {
    navigator.clipboard.writeText(textToCopy).then(() => {
      console.log('Successfully copied to clipboard');
      alert('Copied Order IDs to clipboard!');
    }).catch(err => {
      console.error('Failed to copy text: ', err);
      fallbackCopyTextToClipboard(textToCopy);
    });
  }
})();
