document.getElementById('copyBtn').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      files: ['content.js']
    }).then(() => {
      console.log('Script executed');
    }).catch(err => {
      console.error('Failed to execute script:', err);
    });
  });
});
