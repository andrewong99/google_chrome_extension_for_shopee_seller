chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: clickToParcel
    });
  } catch (error) {
    console.error('Failed to click "Parcel":', error);
  }
});

function clickToParcel() {
  const elements = document.querySelectorAll('body *:not(script):not(style):not(noscript)');
  elements.forEach(element => {
    if (element.children.length === 0 && element.textContent.includes('Parcel')) {
      const textNodes = Array.from(element.childNodes).filter(node => node.nodeType === Node.TEXT_NODE);
      textNodes.forEach(textNode => {
        const content = textNode.textContent;
        let position = 0;
        while ((position = content.indexOf('Parcel', position)) !== -1) {
          const span = document.createElement('span');
          span.textContent = 'Parcel';
          span.style.cursor = 'pointer';
          span.addEventListener('click', () => {
            span.click();
          });
          const before = content.substring(0, position);
          const after = content.substring(position + 'Parcel'.length);
          textNode.textContent = before;
          const afterNode = document.createTextNode(after);
          textNode.parentNode.insertBefore(span, textNode.nextSibling);
          textNode.parentNode.insertBefore(afterNode, span.nextSibling);
          span.click();
          position += 'Parcel'.length;
        }
      });
    }
  });
}
