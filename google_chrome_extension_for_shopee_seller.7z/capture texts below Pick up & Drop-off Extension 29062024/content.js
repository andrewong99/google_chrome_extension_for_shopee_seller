(function() {
  let textToCopy = [];
  const bodyText = document.body.innerText.split('\n');
  
  for (let i = 0; i < bodyText.length; i++) {
    if (bodyText[i].includes("Pick up")) {
      if (i + 1 < bodyText.length) {
        textToCopy.push(bodyText[i + 1].trim());
      }
    } else if (bodyText[i].includes("Drop-off")) {
      if (i + 1 < bodyText.length) {
        textToCopy.push(bodyText[i + 1].trim());
      }
    }
  }

  const textToCopyString = textToCopy.join('\n');
  console.log('Text found below "Pick up" and "Drop-off":', textToCopyString);

  // Fallback method to copy text to clipboard
  function fallbackCopyTextToClipboard(text) {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      const successful = document.execCommand('copy');
      const msg = successful ? 'successful' : 'unsuccessful';
      console.log('Fallback: Copying text command was ' + msg);
      alert('Copied text to clipboard!');
    } catch (err) {
      console.error('Fallback: Oops, unable to copy', err);
    }
    document.body.removeChild(textArea);
  }

  if (!navigator.clipboard) {
    console.warn('Clipboard API not available, using fallback method');
    fallbackCopyTextToClipboard(textToCopyString);
  } else {
    navigator.clipboard.writeText(textToCopyString).then(() => {
      console.log('Successfully copied to clipboard');
      alert('Copied text to clipboard!');
    }).catch(err => {
      console.error('Failed to copy text: ', err);
      fallbackCopyTextToClipboard(textToCopyString);
    });
  }
})();
