(function() {
  let rmNumbers = [];
  // Updated regex to capture numbers with optional decimal points
  const regex = /RM\s*([\d,]+(?:\.\d+)?)/g;
  const bodyText = document.body.innerText;
  let match;
  
  while ((match = regex.exec(bodyText)) !== null) {
    rmNumbers.push(match[1]);
  }
  
  const textToCopy = rmNumbers.join('\n');
  console.log('Numbers found:', textToCopy);

  // Fallback method to copy text to clipboard
  function fallbackCopyTextToClipboard(text) {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      const successful = document.execCommand('copy');
      const msg = successful ? 'successful' : 'unsuccessful';
      console.log('Fallback: Copying text command was ' + msg);
      alert('Copied RM numbers to clipboard!');
    } catch (err) {
      console.error('Fallback: Oops, unable to copy', err);
    }
    document.body.removeChild(textArea);
  }

  if (!navigator.clipboard) {
    console.warn('Clipboard API not available, using fallback method');
    fallbackCopyTextToClipboard(textToCopy);
  } else {
    navigator.clipboard.writeText(textToCopy).then(() => {
      console.log('Successfully copied to clipboard');
      alert('Copied RM numbers to clipboard!');
    }).catch(err => {
      console.error('Failed to copy text: ', err);
      fallbackCopyTextToClipboard(textToCopy);
    });
  }
})();
